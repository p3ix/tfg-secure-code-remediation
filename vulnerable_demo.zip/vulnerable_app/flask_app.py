"""Servidor Flask con debug=True (CWE-94 / exposición de consola)."""
from flask import Flask

app = Flask(__name__)


@app.route("/")
def index():
    return "hola"


if __name__ == "__main__":
    # Vulnerable: debug=True expone el debugger de Werkzeug en producción
    app.run(host="0.0.0.0", debug=True)
