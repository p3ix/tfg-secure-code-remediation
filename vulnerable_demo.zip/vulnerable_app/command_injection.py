"""Ejemplos de inyección de comandos (CWE-78)."""
import os
import subprocess


def borrar_logs(nombre: str) -> None:
    # Vulnerable: concatena entrada del usuario en os.system
    os.system("rm -rf /var/log/" + nombre)


def ping(host: str) -> None:
    # Vulnerable: shell=True con cadena construida por el usuario
    subprocess.call("ping -c 1 " + host, shell=True)
