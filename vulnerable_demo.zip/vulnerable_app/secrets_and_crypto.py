"""Secreto embebido y criptografía débil (CWE-798 / CWE-327)."""
import hashlib

# Vulnerable: credencial embebida en el código fuente
API_PASSWORD = "SuperSecret123!"


def hash_password(password: str) -> str:
    # Vulnerable: MD5 es un algoritmo de hash débil
    return hashlib.md5(password.encode()).hexdigest()


def run_eval(expr: str):
    # Vulnerable: eval sobre entrada no confiable permite ejecución de código
    return eval(expr)
