"""Peticiones HTTP inseguras (CWE-295 / falta de timeout)."""
import requests


def fetch(url: str):
    # Vulnerable: verify=False desactiva la validación del certificado TLS
    return requests.get(url, verify=False)


def fetch_no_timeout(url: str):
    # Vulnerable: petición sin timeout puede colgar el proceso
    return requests.get(url)
