"""Deserialización insegura de YAML (CWE-502)."""
import yaml


def load_config(data: str):
    # Vulnerable: yaml.load con Loader inseguro permite ejecución de objetos
    return yaml.load(data, Loader=yaml.Loader)
