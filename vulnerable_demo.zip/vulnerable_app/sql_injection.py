"""Inyección SQL por interpolación de cadenas (CWE-89)."""
import sqlite3


def get_user(username: str):
    conn = sqlite3.connect("app.db")
    cursor = conn.cursor()
    # Vulnerable: f-string con entrada del usuario en la consulta
    query = f"SELECT * FROM users WHERE username = '{username}'"
    return cursor.execute(query).fetchall()
